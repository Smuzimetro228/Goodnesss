package ua.fliptime.platecases;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.java.JavaPlugin;
import ua.fliptime.platecases.command.PcasesCommand;
import ua.fliptime.platecases.gui.Gui;
import ua.fliptime.platecases.gui.GuiListener;
import ua.fliptime.platecases.gui.GuiManager;
import ua.fliptime.platecases.listener.CaseListener;
import ua.fliptime.platecases.manager.CaseManager;
import ua.fliptime.platecases.manager.LootManager;
import ua.fliptime.platecases.manager.Messages;
import ua.fliptime.platecases.manager.PlateManager;
import ua.fliptime.platecases.manager.StatsManager;
import ua.fliptime.platecases.model.CaseLootHolder;
import ua.fliptime.platecases.util.FileService;

import java.io.File;

public final class PlateCasesPlugin extends JavaPlugin {
    private FileService files;
    private Messages messages;
    private PlateManager plates;
    private LootManager loot;
    private CaseManager cases;
    private StatsManager stats;
    private GuiManager gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        files = new FileService(this);
        messages = new Messages(this);
        plates = new PlateManager(this);
        loot = new LootManager(this);
        cases = new CaseManager(this);
        stats = new StatsManager(this);
        gui = new GuiManager(this);
        loadAll();

        getServer().getPluginManager().registerEvents(new CaseListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        PluginCommand cmd = getCommand("pcases");
        if (cmd != null) {
            PcasesCommand handler = new PcasesCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
        getLogger().info("PlateCases увімкнено. Автор: FlipTime");
    }

    /** Повне (пере)завантаження усіх конфігурацій без перезапуску сервера. */
    public void loadAll() {
        files.flush();
        reloadConfig();
        messages.load();
        plates.load();
        loot.load();
        cases.load();
        stats.load();
    }

    public void saveConfigAsync() {
        FileConfiguration cfg = getConfig();
        files.saveAsync(new File(getDataFolder(), "config.yml"), cfg);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            InventoryHolder h = p.getOpenInventory().getTopInventory().getHolder();
            if (h instanceof CaseLootHolder || h instanceof Gui) p.closeInventory();
        }
        if (stats != null) stats.save();
        if (files != null) files.shutdown();
    }

    public FileService files() {
        return files;
    }

    public Messages messages() {
        return messages;
    }

    public PlateManager plates() {
        return plates;
    }

    public LootManager loot() {
        return loot;
    }

    public CaseManager cases() {
        return cases;
    }

    public StatsManager stats() {
        return stats;
    }

    public GuiManager gui() {
        return gui;
    }
}
