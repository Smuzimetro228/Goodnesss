package ua.fliptime.platecases.command;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.CaseBlock;
import ua.fliptime.platecases.model.PlateType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PcasesCommand implements TabExecutor {
    private final PlateCasesPlugin plugin;

    public PcasesCommand(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("platecases.admin")) {
            plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "menu" -> {
                if (!(sender instanceof Player p)) {
                    plugin.messages().send(sender, "player-only");
                    return true;
                }
                plugin.gui().openMain(p);
            }
            case "place" -> place(sender, args);
            case "give" -> give(sender, args);
            case "reload" -> {
                plugin.loadAll();
                plugin.messages().send(sender, "reloaded");
            }
            case "remove" -> remove(sender, args);
            case "list" -> list(sender);
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender s) {
        for (String line : plugin.messages().list("help")) {
            s.sendMessage(ua.fliptime.platecases.util.Text.parse(line));
        }
    }

    private void place(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.messages().send(sender, "player-only");
            return;
        }
        if (args.length < 2) {
            plugin.messages().send(sender, "usage-place");
            return;
        }
        Material type;
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "chest" -> type = Material.CHEST;
            case "barrel" -> type = Material.BARREL;
            default -> {
                plugin.messages().send(sender, "usage-place");
                return;
            }
        }
        plugin.gui().placeAndNotify(p, type);
    }

    private void give(CommandSender sender, String[] args) {
        // /pcases give <plate> [amount]  |  /pcases give <player> <plate> [amount]
        Player target;
        PlateType plate;
        String amountArg;
        if (args.length >= 2 && plugin.plates().get(args[1]) != null) {
            if (!(sender instanceof Player p)) {
                plugin.messages().send(sender, "player-only");
                return;
            }
            target = p;
            plate = plugin.plates().get(args[1]);
            amountArg = args.length >= 3 ? args[2] : null;
        } else if (args.length >= 3) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                plugin.messages().send(sender, "player-not-found", "player", args[1]);
                return;
            }
            plate = plugin.plates().get(args[2]);
            if (plate == null) {
                plugin.messages().send(sender, "unknown-plate", "plate", args[2]);
                return;
            }
            amountArg = args.length >= 4 ? args[3] : null;
        } else {
            plugin.messages().send(sender, "usage-give");
            return;
        }
        int amount = 1;
        if (amountArg != null) {
            try {
                amount = Math.max(1, Math.min(256, Integer.parseInt(amountArg)));
            } catch (NumberFormatException ex) {
                plugin.messages().send(sender, "usage-give");
                return;
            }
        }
        plugin.plates().give(target, plate, amount);
        plugin.messages().send(sender, "plate-given", "amount", String.valueOf(amount), "plate", plate.name,
                "player", target.getName());
        if (target != sender) {
            plugin.messages().send(target, "plate-received", "amount", String.valueOf(amount), "plate", plate.name);
        }
    }

    private void remove(CommandSender sender, String[] args) {
        CaseBlock cb = null;
        if (args.length >= 2) {
            cb = plugin.cases().byId(args[1]);
        } else if (sender instanceof Player p) {
            Block b = p.getTargetBlockExact(6);
            if (b != null) cb = plugin.cases().find(b);
        }
        if (cb == null) {
            plugin.messages().send(sender, "remove-none");
            return;
        }
        plugin.cases().remove(cb);
        plugin.messages().send(sender, "removed", "id", cb.id());
    }

    private void list(CommandSender sender) {
        List<CaseBlock> all = plugin.cases().snapshot();
        if (all.isEmpty()) {
            plugin.messages().send(sender, "list-empty");
            return;
        }
        plugin.messages().send(sender, "list-header", "count", String.valueOf(all.size()));
        int shown = 0;
        for (CaseBlock cb : all) {
            if (shown++ >= 50) break;
            World w = Bukkit.getWorld(cb.world());
            plugin.messages().send(sender, "list-entry", "id", cb.id(), "type", cb.type().name(),
                    "world", w == null ? "?" : w.getName(), "x", String.valueOf(cb.x()),
                    "y", String.valueOf(cb.y()), "z", String.valueOf(cb.z()));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("platecases.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("menu", "place", "give", "reload", "remove", "list")) add(out, s, args[0]);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "place" -> {
                    add(out, "chest", args[1]);
                    add(out, "barrel", args[1]);
                }
                case "give" -> {
                    for (PlateType t : plugin.plates().all()) add(out, t.id, args[1]);
                    for (Player p : Bukkit.getOnlinePlayers()) add(out, p.getName(), args[1]);
                }
                case "remove" -> {
                    for (CaseBlock cb : plugin.cases().snapshot()) add(out, cb.id(), args[1]);
                }
                default -> {
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            if (plugin.plates().get(args[1]) == null) {
                for (PlateType t : plugin.plates().all()) add(out, t.id, args[2]);
            } else {
                add(out, "1", args[2]);
                add(out, "10", args[2]);
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            add(out, "1", args[3]);
            add(out, "10", args[3]);
        }
        return out;
    }

    private static void add(List<String> out, String candidate, String typed) {
        if (candidate.toLowerCase(Locale.ROOT).startsWith(typed.toLowerCase(Locale.ROOT))) out.add(candidate);
    }
}
