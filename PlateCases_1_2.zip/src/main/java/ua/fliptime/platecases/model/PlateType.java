package ua.fliptime.platecases.model;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;

/** Опис однієї платівки (рівня). Усі поля змінюються через items.yml або GUI. */
public final class PlateType {

    public static final class SoundCfg {
        public String key = "";
        public float volume = 1.0f;
        public float pitch = 1.0f;

        void load(ConfigurationSection s, String path) {
            key = s.getString(path + ".key", "");
            volume = (float) s.getDouble(path + ".volume", 1.0);
            pitch = (float) s.getDouble(path + ".pitch", 1.0);
        }

        void save(ConfigurationSection s, String path) {
            s.set(path + ".key", key);
            s.set(path + ".volume", (double) volume);
            s.set(path + ".pitch", (double) pitch);
        }
    }

    public final String id;
    public int level = 1;
    public String name = "&fПлатівка";
    public Material material = Material.PAPER;
    public int customModelData = 0;
    public boolean glow = true;
    public List<String> lore = new ArrayList<>();
    public List<String> itemFlags = new ArrayList<>();
    public String chestTitle = "&8Скриня";
    public String lootFile;
    public final SoundCfg openSound = new SoundCfg();
    public final SoundCfg revealSound = new SoundCfg();
    public boolean particlesEnabled = true;
    public String particleType = "END_ROD";
    public int particleCount = 30;

    public PlateType(String id) {
        this.id = id;
        this.lootFile = "loot/" + id + ".yml";
    }

    public void load(ConfigurationSection s) {
        level = Math.max(1, s.getInt("level", 1));
        name = s.getString("name", "&fПлатівка");
        Material m = Material.matchMaterial(s.getString("material", "PAPER"));
        material = (m != null && m.isItem()) ? m : Material.PAPER;
        customModelData = Math.max(0, s.getInt("custom-model-data", 0));
        glow = s.getBoolean("glow", true);
        lore = new ArrayList<>(s.getStringList("lore"));
        itemFlags = new ArrayList<>(s.getStringList("item-flags"));
        chestTitle = s.getString("chest-title", "&8Скриня");
        lootFile = s.getString("loot-file", "loot/" + id + ".yml");
        openSound.load(s, "open-sound");
        revealSound.load(s, "reveal-sound");
        particlesEnabled = s.getBoolean("particles.enabled", true);
        particleType = s.getString("particles.type", "END_ROD");
        particleCount = Math.max(1, s.getInt("particles.count", 30));
    }

    public void save(ConfigurationSection s) {
        s.set("level", level);
        s.set("name", name);
        s.set("material", material.name());
        s.set("custom-model-data", customModelData);
        s.set("glow", glow);
        s.set("lore", lore);
        s.set("item-flags", itemFlags);
        s.set("chest-title", chestTitle);
        s.set("loot-file", lootFile);
        openSound.save(s, "open-sound");
        revealSound.save(s, "reveal-sound");
        s.set("particles.enabled", particlesEnabled);
        s.set("particles.type", particleType);
        s.set("particles.count", particleCount);
    }
}
