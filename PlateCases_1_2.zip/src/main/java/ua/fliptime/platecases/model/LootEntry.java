package ua.fliptime.platecases.model;

import org.bukkit.inventory.ItemStack;

/** Один предмет у таблиці луту: шаблон, шанс (0–100) та діапазон кількості. */
public final class LootEntry {
    public ItemStack item;
    public double chance;
    public int min;
    public int max;

    public LootEntry(ItemStack item, double chance, int min, int max) {
        this.item = item.clone();
        this.item.setAmount(1);
        this.chance = clampChance(chance);
        this.min = Math.max(1, min);
        this.max = Math.max(this.min, max);
    }

    public static double clampChance(double c) {
        double v = Math.max(0.0, Math.min(100.0, c));
        return Math.round(v * 10.0) / 10.0;
    }

    public void addChance(double delta) {
        chance = clampChance(chance + delta);
    }

    public void setMin(int v) {
        min = Math.max(1, Math.min(6400, v));
        if (max < min) max = min;
    }

    public void setMax(int v) {
        max = Math.max(1, Math.min(6400, v));
        if (min > max) min = max;
    }
}
