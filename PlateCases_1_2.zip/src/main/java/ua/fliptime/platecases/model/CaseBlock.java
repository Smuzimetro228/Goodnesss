package ua.fliptime.platecases.model;

import org.bukkit.Material;

import java.util.UUID;

/** Зареєстрований спеціальний сундук або бочка. */
public record CaseBlock(String id, UUID world, int x, int y, int z, Material type) {
}
