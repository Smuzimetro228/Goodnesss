package ua.fliptime.platecases.model;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Таблиця луту одного рівня платівки. */
public final class LootTable {
    private int rolls = 1;
    private final List<LootEntry> entries = new ArrayList<>();

    public int rolls() {
        return rolls;
    }

    public void setRolls(int r) {
        rolls = Math.max(1, Math.min(20, r));
    }

    public List<LootEntry> entries() {
        return entries;
    }

    public boolean isEmpty() {
        return entries.isEmpty();
    }

    /**
     * Генерує вміст: кожен «ролл» перебирає всі записи у випадковому порядку, кожен запис
     * проходить свій шанс, кількість береться випадково з [min;max], а стаки кладуться
     * у випадкові різні слоти. Слоти, що лишилися, — порожні.
     */
    public ItemStack[] generate(int size) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        List<Integer> free = new ArrayList<>(size);
        for (int i = 0; i < size; i++) free.add(i);
        Collections.shuffle(free, rnd);

        ItemStack[] out = new ItemStack[size];
        int used = 0;
        List<LootEntry> order = new ArrayList<>(entries);
        for (int r = 0; r < rolls; r++) {
            Collections.shuffle(order, rnd);
            for (LootEntry e : order) {
                if (used >= free.size()) return out;
                if (rnd.nextDouble() * 100.0 >= e.chance) continue;
                int amount = e.min >= e.max ? e.min : rnd.nextInt(e.min, e.max + 1);
                int stackMax = Math.max(1, e.item.getMaxStackSize());
                while (amount > 0 && used < free.size()) {
                    int n = Math.min(amount, stackMax);
                    ItemStack st = e.item.clone();
                    st.setAmount(n);
                    out[free.get(used++)] = st;
                    amount -= n;
                }
            }
        }
        return out;
    }

    public void load(ConfigurationSection root) {
        entries.clear();
        setRolls(root.getInt("rolls", 1));
        ConfigurationSection sec = root.getConfigurationSection("entries");
        if (sec == null) return;
        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.sort((a, b) -> {
            try {
                return Integer.compare(Integer.parseInt(a), Integer.parseInt(b));
            } catch (NumberFormatException ex) {
                return a.compareTo(b);
            }
        });
        for (String k : keys) {
            ItemStack it = sec.getItemStack(k + ".item");
            if (it == null || it.getType().isAir()) continue;
            entries.add(new LootEntry(it, sec.getDouble(k + ".chance", 100.0),
                    sec.getInt(k + ".min", 1), sec.getInt(k + ".max", 1)));
        }
    }

    public void save(ConfigurationSection root) {
        root.set("rolls", rolls);
        root.set("entries", null);
        int i = 0;
        for (LootEntry e : entries) {
            String p = "entries." + i++;
            root.set(p + ".item", e.item);
            root.set(p + ".chance", e.chance);
            root.set(p + ".min", e.min);
            root.set(p + ".max", e.max);
        }
    }
}
