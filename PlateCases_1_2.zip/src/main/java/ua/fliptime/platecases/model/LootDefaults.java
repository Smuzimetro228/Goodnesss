package ua.fliptime.platecases.model;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

/** Лут за замовчуванням — створюється лише якщо файл loot/levelN.yml ще не існує. */
public final class LootDefaults {
    private LootDefaults() {
    }

    private static ItemStack strengthPotion() {
        ItemStack p = new ItemStack(Material.POTION);
        PotionMeta pm = (PotionMeta) p.getItemMeta();
        pm.setBasePotionType(PotionType.STRENGTH);
        p.setItemMeta(pm);
        return p;
    }

    private static void add(LootTable t, Material m, double chance, int min, int max) {
        t.entries().add(new LootEntry(new ItemStack(m), chance, min, max));
    }

    public static LootTable forLevel(int level) {
        LootTable t = new LootTable();
        t.setRolls(1);
        switch (level) {
            case 1 -> {
                add(t, Material.DIAMOND, 100, 5, 5);
                add(t, Material.GOLDEN_APPLE, 100, 3, 3);
                add(t, Material.NETHERITE_CHESTPLATE, 100, 1, 1);
                add(t, Material.GOLDEN_CARROT, 100, 16, 16);
                t.entries().add(new LootEntry(strengthPotion(), 100, 2, 2));
            }
            case 2 -> {
                add(t, Material.DIAMOND, 100, 8, 16);
                add(t, Material.ENCHANTED_GOLDEN_APPLE, 60, 1, 2);
                add(t, Material.NETHERITE_INGOT, 70, 1, 3);
                add(t, Material.GOLDEN_CARROT, 100, 32, 64);
                add(t, Material.EXPERIENCE_BOTTLE, 80, 16, 32);
                add(t, Material.NETHERITE_SWORD, 25, 1, 1);
                t.entries().add(new LootEntry(strengthPotion(), 100, 2, 4));
            }
            default -> {
                add(t, Material.DIAMOND_BLOCK, 100, 2, 6);
                add(t, Material.ENCHANTED_GOLDEN_APPLE, 100, 3, 5);
                add(t, Material.NETHERITE_INGOT, 100, 4, 8);
                add(t, Material.NETHERITE_HELMET, 40, 1, 1);
                add(t, Material.NETHERITE_CHESTPLATE, 40, 1, 1);
                add(t, Material.NETHERITE_LEGGINGS, 40, 1, 1);
                add(t, Material.NETHERITE_BOOTS, 40, 1, 1);
                add(t, Material.NETHERITE_SWORD, 40, 1, 1);
                add(t, Material.TOTEM_OF_UNDYING, 70, 1, 2);
                add(t, Material.BEACON, 20, 1, 1);
                add(t, Material.ELYTRA, 10, 1, 1);
                add(t, Material.GOLDEN_CARROT, 100, 64, 64);
            }
        }
        return t;
    }
}
