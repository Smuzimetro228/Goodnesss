package ua.fliptime.platecases.model;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

/** Власник віртуального вікна з лутом: одне використання платівки = одне окреме вікно. */
public final class CaseLootHolder implements InventoryHolder {
    public final String plateId;
    public final String caseId;
    public final UUID player;
    public boolean closed;
    private Inventory inventory;

    public CaseLootHolder(String plateId, String caseId, UUID player) {
        this.plateId = plateId;
        this.caseId = caseId;
        this.player = player;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
