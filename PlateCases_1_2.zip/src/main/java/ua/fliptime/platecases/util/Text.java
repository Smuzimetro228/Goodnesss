package ua.fliptime.platecases.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

import java.util.Map;

/** Підтримка &-кодів, HEX (&#RRGGBB) та MiniMessage в одному рядку. */
public final class Text {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Map<Character, String> CODES = Map.ofEntries(
            Map.entry('0', "<black>"), Map.entry('1', "<dark_blue>"), Map.entry('2', "<dark_green>"),
            Map.entry('3', "<dark_aqua>"), Map.entry('4', "<dark_red>"), Map.entry('5', "<dark_purple>"),
            Map.entry('6', "<gold>"), Map.entry('7', "<gray>"), Map.entry('8', "<dark_gray>"),
            Map.entry('9', "<blue>"), Map.entry('a', "<green>"), Map.entry('b', "<aqua>"),
            Map.entry('c', "<red>"), Map.entry('d', "<light_purple>"), Map.entry('e', "<yellow>"),
            Map.entry('f', "<white>"), Map.entry('k', "<obfuscated>"), Map.entry('l', "<bold>"),
            Map.entry('m', "<strikethrough>"), Map.entry('n', "<underlined>"), Map.entry('o', "<italic>"),
            Map.entry('r', "<reset>"));

    private Text() {
    }

    private static boolean isHex(String s) {
        if (s.length() != 6) return false;
        for (int i = 0; i < 6; i++) {
            if (Character.digit(s.charAt(i), 16) < 0) return false;
        }
        return true;
    }

    public static String toMini(String in) {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder(in.length() + 16);
        for (int i = 0; i < in.length(); i++) {
            char c = in.charAt(i);
            if ((c == '&' || c == '§') && i + 1 < in.length()) {
                char n = in.charAt(i + 1);
                if (n == '#' && i + 7 < in.length()) {
                    String hex = in.substring(i + 2, i + 8);
                    if (isHex(hex)) {
                        sb.append("<#").append(hex).append('>');
                        i += 7;
                        continue;
                    }
                }
                String r = CODES.get(Character.toLowerCase(n));
                if (r != null) {
                    sb.append(r);
                    i++;
                    continue;
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }

    public static Component parse(String s) {
        try {
            return MM.deserialize(toMini(s));
        } catch (Exception ex) {
            return Component.text(s == null ? "" : s);
        }
    }

    /** Для назв та опису предметів: без курсиву за замовчуванням. */
    public static Component item(String s) {
        return Component.empty().decoration(TextDecoration.ITALIC, false).append(parse(s));
    }

    public static String plain(Component c) {
        return PlainTextComponentSerializer.plainText().serialize(c);
    }
}
