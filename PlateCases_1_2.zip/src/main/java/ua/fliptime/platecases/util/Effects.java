package ua.fliptime.platecases.util;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import ua.fliptime.platecases.model.PlateType;

import java.util.Locale;

public final class Effects {
    private Effects() {
    }

    public static void sound(Location loc, PlateType.SoundCfg s) {
        if (s == null || s.key == null || s.key.isBlank()) return;
        World w = loc.getWorld();
        if (w == null) return;
        try {
            w.playSound(loc, s.key.trim(), SoundCategory.BLOCKS, s.volume, s.pitch);
        } catch (Exception ignored) {
        }
    }

    /** Пошук частинки за назвою (працює і для enum, і для реєстру). */
    public static Particle particle(String name) {
        if (name == null || name.isBlank()) return null;
        try {
            Object o = Particle.class.getField(name.trim().toUpperCase(Locale.ROOT)).get(null);
            return o instanceof Particle p ? p : null;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    public static void burst(Location loc, PlateType t) {
        Particle p = particle(t.particleType);
        World w = loc.getWorld();
        if (p == null || w == null) return;
        try {
            w.spawnParticle(p, loc, Math.max(1, t.particleCount), 0.4, 0.4, 0.4, 0.05);
        } catch (Exception ignored) {
        }
    }

    /** Спіральна анімація навколо блока (~1 секунда). */
    public static void spiral(Plugin plugin, Location center, PlateType t) {
        Particle p = particle(t.particleType);
        World w = center.getWorld();
        if (p == null || w == null) return;
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (tick++ >= 20) {
                    cancel();
                    return;
                }
                double ang = tick * Math.PI / 5.0;
                for (int k = 0; k < 2; k++) {
                    double a = ang + k * Math.PI;
                    Location l = center.clone().add(Math.cos(a) * 0.9, 0.2 + tick * 0.04, Math.sin(a) * 0.9);
                    try {
                        w.spawnParticle(p, l, 1, 0, 0, 0, 0);
                    } catch (Exception ex) {
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
