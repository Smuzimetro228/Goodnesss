package ua.fliptime.platecases.util;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/** Завантаження YAML та асинхронне (в одному потоці, по черзі) збереження на диск. */
public final class FileService {
    private final JavaPlugin plugin;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "PlateCases-IO");
        t.setDaemon(true);
        return t;
    });

    public FileService(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public File file(String path) {
        return new File(plugin.getDataFolder(), path);
    }

    public YamlConfiguration load(String path) {
        File f = file(path);
        if (!f.exists()) {
            File parent = f.getParentFile();
            if (parent != null) parent.mkdirs();
            if (plugin.getResource(path) != null) {
                plugin.saveResource(path, false);
            } else {
                try {
                    f.createNewFile();
                } catch (IOException e) {
                    plugin.getLogger().log(Level.SEVERE, "Не вдалося створити " + path, e);
                }
            }
        }
        return YamlConfiguration.loadConfiguration(f);
    }

    /** Знімок даних береться в основному потоці, запис іде в окремому. */
    public void saveAsync(File f, FileConfiguration cfg) {
        String data = cfg.saveToString();
        try {
            io.execute(() -> write(f, data));
        } catch (RuntimeException ex) {
            write(f, data);
        }
    }

    public void appendLine(String path, String line) {
        File f = file(path);
        try {
            io.execute(() -> {
                try {
                    Path p = f.toPath();
                    if (p.getParent() != null) Files.createDirectories(p.getParent());
                    Files.writeString(p, line + System.lineSeparator(), StandardCharsets.UTF_8,
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException e) {
                    plugin.getLogger().log(Level.WARNING, "Не вдалося дописати " + path, e);
                }
            });
        } catch (RuntimeException ignored) {
        }
    }

    private void write(File f, String data) {
        try {
            Path p = f.toPath();
            if (p.getParent() != null) Files.createDirectories(p.getParent());
            Path tmp = p.resolveSibling(f.getName() + ".tmp");
            Files.writeString(tmp, data, StandardCharsets.UTF_8);
            try {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Не вдалося зберегти " + f.getName(), e);
        }
    }

    /** Дочекатися завершення всіх відкладених записів. */
    public void flush() {
        try {
            io.submit(() -> { }).get(10, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }

    public void shutdown() {
        io.shutdown();
        try {
            io.awaitTermination(15, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
