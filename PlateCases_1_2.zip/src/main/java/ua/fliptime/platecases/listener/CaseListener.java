package ua.fliptime.platecases.listener;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.CaseBlock;
import ua.fliptime.platecases.model.CaseLootHolder;
import ua.fliptime.platecases.model.LootTable;
import ua.fliptime.platecases.model.PlateType;
import ua.fliptime.platecases.util.Effects;
import ua.fliptime.platecases.util.Text;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Логіка відкриття: ПКМ платівкою по спеціальному сундуку -> платівка витрачається ->
 * гравець бачить ОКРЕМЕ віртуальне вікно з новим лутом. Закрив — решта луту зникає.
 * Сам сундук ніколи не «використовується назавжди», тож платівок можна юзати підряд.
 */
public final class CaseListener implements Listener {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final PlateCasesPlugin plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public CaseListener(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- відкриття

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = e.getClickedBlock();
        if (block == null) return;
        CaseBlock cb = plugin.cases().find(block);
        if (cb == null) return;

        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        PlateType plate = plugin.plates().identify(hand);

        // Режим будівництва: sneak + блок у руці -> ставимо блок, а не відкриваємо
        if (p.isSneaking() && plate == null && hand.getType().isBlock() && !hand.getType().isAir()) return;

        // Ванільне відкриття блокуємо завжди
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setCancelled(true);

        // Лише основна рука; друга рука ніколи не відкриває
        if (e.getHand() != EquipmentSlot.HAND) return;

        if (!p.hasPermission("platecases.use")) {
            plugin.messages().send(p, "no-use-permission");
            return;
        }
        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("settings.click-cooldown-ms", 400L);
        Long last = cooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) return;
        cooldown.put(p.getUniqueId(), now);

        if (plate == null) {
            plugin.messages().send(p, plugin.plates().hasPlateTag(hand) ? "wrong-plate" : "no-plate");
            return;
        }
        openCase(p, block, cb, plate);
    }

    private void openCase(Player p, Block block, CaseBlock cb, PlateType plate) {
        LootTable table = plugin.loot().get(plate.id);
        if (table.isEmpty()) {
            plugin.messages().send(p, "loot-empty");
            return;
        }
        int size = plugin.cases().inventorySize(block);

        // 1) Усі перевірки та генерація — ДО витрачання платівки
        ItemStack[] items = table.generate(size);
        CaseLootHolder holder = new CaseLootHolder(plate.id, cb.id(), p.getUniqueId());
        Component title = Text.parse(plate.chestTitle.replace("{level}", String.valueOf(plate.level)));
        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);
        inv.setContents(items);

        // 2) Витрата рівно однієї платівки з основної руки
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (plugin.plates().identify(hand) != plate) return;
        boolean consume = !(p.getGameMode() == GameMode.CREATIVE
                && !plugin.getConfig().getBoolean("settings.consume-in-creative", true));
        if (consume) {
            int amount = hand.getAmount();
            if (amount <= 1) {
                p.getInventory().setItemInMainHand(null);
            } else {
                ItemStack rest = hand.clone();
                rest.setAmount(amount - 1);
                p.getInventory().setItemInMainHand(rest);
            }
        }

        // 3) Відкриваємо вікно; якщо інший плагін скасував — повертаємо платівку
        InventoryView view = p.openInventory(inv);
        if (view == null) {
            if (consume) plugin.plates().give(p, plate, 1);
            return;
        }

        plugin.messages().send(p, "opened", "plate", plate.name);
        Location center = block.getLocation().add(0.5, 0.6, 0.5);
        if (plugin.getConfig().getBoolean("effects.sounds-enabled", true)) {
            Effects.sound(center, plate.openSound);
            Effects.sound(center, plate.revealSound);
        }
        if (plate.particlesEnabled && plugin.getConfig().getBoolean("effects.particles-enabled", true)) {
            Effects.burst(center, plate);
            if (plugin.getConfig().getBoolean("effects.animation-enabled", true)) {
                Effects.spiral(plugin, center, plate);
            }
        }
        plugin.stats().record(plate, p);
        if (plugin.getConfig().getBoolean("settings.log-openings", true)) {
            int count = 0;
            for (ItemStack it : items) if (it != null) count++;
            String line = "[" + LocalDateTime.now().format(TIME) + "] " + p.getName() + " використав "
                    + plate.id + " на сундуку " + cb.id() + " (" + block.getWorld().getName() + " "
                    + block.getX() + " " + block.getY() + " " + block.getZ() + "), стаків: " + count;
            plugin.getLogger().info(line);
            plugin.files().appendLine("opens.log", line);
        }
    }

    // ---------------------------------------------------------------- вікно з лутом

    private static boolean isLootView(InventoryView v) {
        return v.getTopInventory().getHolder() instanceof CaseLootHolder;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        if (!isLootView(e.getView())) return;
        Inventory top = e.getView().getTopInventory();
        if (e.getClickedInventory() == null) return;
        InventoryAction a = e.getAction();
        boolean inTop = e.getRawSlot() < top.getSize();
        if (inTop) {
            switch (a) {
                case PICKUP_ALL, PICKUP_HALF, PICKUP_ONE, PICKUP_SOME, MOVE_TO_OTHER_INVENTORY,
                     DROP_ALL_SLOT, DROP_ONE_SLOT -> {
                    // дозволено лише ЗАБИРАТИ
                }
                case HOTBAR_SWAP -> {
                    int btn = e.getHotbarButton();
                    ItemStack target = btn >= 0 ? e.getWhoClicked().getInventory().getItem(btn)
                            : e.getWhoClicked().getInventory().getItemInOffHand();
                    if (target != null && !target.getType().isAir()) e.setCancelled(true);
                }
                default -> e.setCancelled(true);
            }
        } else if (a == InventoryAction.MOVE_TO_OTHER_INVENTORY || a == InventoryAction.COLLECT_TO_CURSOR) {
            e.setCancelled(true); // не можна класти предмети у вікно луту
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        if (!isLootView(e.getView())) return;
        int size = e.getView().getTopInventory().getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < size) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (!(inv.getHolder() instanceof CaseLootHolder holder)) return;
        if (holder.closed) return;
        holder.closed = true;

        int left = 0;
        boolean drop = plugin.getConfig().getBoolean("close.drop-remaining", false);
        Player p = e.getPlayer() instanceof Player pl ? pl : null;
        for (ItemStack it : inv.getContents()) {
            if (it == null || it.getType().isAir()) continue;
            left++;
            if (drop && p != null) {
                for (ItemStack rest : p.getInventory().addItem(it).values()) {
                    p.getWorld().dropItem(p.getLocation(), rest);
                }
            }
        }
        inv.clear();
        if (p != null && left > 0) {
            plugin.messages().send(p, drop ? "closed-dropped" : "closed-lost", "count", String.valueOf(left));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cooldown.remove(e.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------- захист блоків

    private boolean isCaseInventory(Inventory inv) {
        if (inv == null) return false;
        InventoryType t = inv.getType();
        if (t != InventoryType.CHEST && t != InventoryType.BARREL) return false;
        Location l = inv.getLocation();
        if (l == null || l.getWorld() == null) return false;
        return plugin.cases().find(l.getBlock()) != null;
    }

    /** Реальний інвентар спеціального блока завжди порожній і недоступний. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (isCaseInventory(e.getInventory())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(InventoryMoveItemEvent e) {
        if (isCaseInventory(e.getDestination()) || isCaseInventory(e.getSource())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (plugin.cases().find(e.getBlock()) != null) {
            e.setCancelled(true);
            plugin.messages().send(e.getPlayer(), "break-denied");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.cases().find(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.cases().find(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.cases().find(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.cases().find(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }
}
