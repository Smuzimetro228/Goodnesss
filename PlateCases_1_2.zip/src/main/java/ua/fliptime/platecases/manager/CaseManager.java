package ua.fliptime.platecases.manager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.CaseBlock;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Реєстр спеціальних сундуків/бочок (chests.yml) + створення та видалення блоків. */
public final class CaseManager {
    private final PlateCasesPlugin plugin;
    private final Map<String, CaseBlock> byLoc = new LinkedHashMap<>();
    private final Map<String, CaseBlock> byId = new LinkedHashMap<>();
    private final NamespacedKey keyCase;

    public CaseManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
        this.keyCase = new NamespacedKey(plugin, "case_id");
    }

    private static String key(UUID world, int x, int y, int z) {
        return world + ":" + x + ":" + y + ":" + z;
    }

    private static String key(Block b) {
        return key(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ());
    }

    public void load() {
        byLoc.clear();
        byId.clear();
        YamlConfiguration y = plugin.files().load("chests.yml");
        ConfigurationSection sec = y.getConfigurationSection("chests");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            try {
                UUID w = UUID.fromString(sec.getString(id + ".world", ""));
                Material m = Material.matchMaterial(sec.getString(id + ".type", "CHEST"));
                if (m == null) m = Material.CHEST;
                CaseBlock cb = new CaseBlock(id, w, sec.getInt(id + ".x"), sec.getInt(id + ".y"),
                        sec.getInt(id + ".z"), m);
                byLoc.put(key(w, cb.x(), cb.y(), cb.z()), cb);
                byId.put(id, cb);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Пропущено пошкоджений запис сундука: " + id);
            }
        }
        plugin.getLogger().info("Завантажено спеціальних сундуків: " + byId.size());
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.createSection("chests");
        for (CaseBlock cb : byId.values()) {
            String p = "chests." + cb.id();
            y.set(p + ".world", cb.world().toString());
            y.set(p + ".x", cb.x());
            y.set(p + ".y", cb.y());
            y.set(p + ".z", cb.z());
            y.set(p + ".type", cb.type().name());
        }
        plugin.files().saveAsync(plugin.files().file("chests.yml"), y);
    }

    public Collection<CaseBlock> all() {
        return byId.values();
    }

    public CaseBlock byId(String id) {
        return byId.get(id);
    }

    private static BlockFace clockwise(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.EAST;
            case EAST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.WEST;
            default -> BlockFace.NORTH;
        };
    }

    /** Шукає спеціальний блок, враховуючи обидві половини подвійного сундука. */
    public CaseBlock find(Block b) {
        Material m = b.getType();
        if (m != Material.CHEST && m != Material.BARREL) return null;
        CaseBlock cb = byLoc.get(key(b));
        if (cb != null) return cb;
        if (m == Material.CHEST && b.getBlockData() instanceof org.bukkit.block.data.type.Chest ch
                && ch.getType() != org.bukkit.block.data.type.Chest.Type.SINGLE) {
            BlockFace cw = clockwise(ch.getFacing());
            BlockFace dir = ch.getType() == org.bukkit.block.data.type.Chest.Type.LEFT ? cw : cw.getOppositeFace();
            Block other = b.getRelative(dir);
            if (other.getType() == Material.CHEST) return byLoc.get(key(other));
        }
        return null;
    }

    public int inventorySize(Block b) {
        FileConfiguration c = plugin.getConfig();
        int size;
        if (b.getType() == Material.BARREL) {
            size = c.getInt("inventory-size.barrel", 27);
        } else if (b.getBlockData() instanceof org.bukkit.block.data.type.Chest ch
                && ch.getType() != org.bukkit.block.data.type.Chest.Type.SINGLE) {
            size = c.getInt("inventory-size.double-chest", 54);
        } else {
            size = c.getInt("inventory-size.chest", 27);
        }
        size = Math.max(9, Math.min(54, size));
        return size - (size % 9);
    }

    /** Створює спеціальний блок у позиції гравця. Повертає null, якщо місце зайняте. */
    public CaseBlock place(Player p, Material type) {
        Block b = p.getLocation().getBlock();
        if (!b.getType().isAir() && !b.isReplaceable()) return null;
        boolean facePlayer = plugin.getConfig().getBoolean("chest.face-player", true);
        BlockFace horizontal = p.getFacing();
        if (facePlayer) horizontal = horizontal.getOppositeFace();

        if (type == Material.BARREL) {
            b.setType(Material.BARREL, false);
            BlockData data = b.getBlockData();
            BlockFace face = horizontal;
            float pitch = p.getLocation().getPitch();
            if (pitch > 55f) face = BlockFace.UP;
            else if (pitch < -55f) face = BlockFace.DOWN;
            if (data instanceof Directional d) {
                d.setFacing(face);
                b.setBlockData(data, false);
            }
            // повний блок: піднімаємо гравця, щоб не застряг усередині
            Location up = p.getLocation().clone();
            up.setY(b.getY() + 1.0);
            p.teleport(up);
        } else {
            b.setType(Material.CHEST, false);
            org.bukkit.block.data.type.Chest cd = (org.bukkit.block.data.type.Chest) b.getBlockData();
            cd.setFacing(horizontal);
            cd.setType(org.bukkit.block.data.type.Chest.Type.SINGLE);
            b.setBlockData(cd, false);
        }

        String id = UUID.randomUUID().toString().substring(0, 8);
        BlockState st = b.getState();
        if (st instanceof TileState ts) {
            ts.getPersistentDataContainer().set(keyCase, PersistentDataType.STRING, id);
            ts.update(true, false);
        }
        World w = b.getWorld();
        CaseBlock cb = new CaseBlock(id, w.getUID(), b.getX(), b.getY(), b.getZ(), b.getType());
        byLoc.put(key(b), cb);
        byId.put(id, cb);
        save();
        return cb;
    }

    /** Видаляє реєстрацію та сам блок. */
    public void remove(CaseBlock cb) {
        byLoc.remove(key(cb.world(), cb.x(), cb.y(), cb.z()));
        byId.remove(cb.id());
        World w = Bukkit.getWorld(cb.world());
        if (w != null) {
            Block b = w.getBlockAt(cb.x(), cb.y(), cb.z());
            if (b.getType() == cb.type()) b.setType(Material.AIR, false);
        }
        save();
    }

    public List<CaseBlock> snapshot() {
        return new ArrayList<>(byId.values());
    }
}
