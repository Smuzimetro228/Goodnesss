package ua.fliptime.platecases.manager;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import net.kyori.adventure.text.Component;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.PlateType;
import ua.fliptime.platecases.util.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class PlateManager {
    private final PlateCasesPlugin plugin;
    private final Map<String, PlateType> plates = new LinkedHashMap<>();
    private YamlConfiguration cfg = new YamlConfiguration();
    public final NamespacedKey keyId;
    public final NamespacedKey keyLevel;

    public PlateManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
        this.keyId = new NamespacedKey(plugin, "plate_id");
        this.keyLevel = new NamespacedKey(plugin, "plate_level");
    }

    public void load() {
        plates.clear();
        cfg = plugin.files().load("items.yml");
        ConfigurationSection sec = cfg.getConfigurationSection("plates");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(id);
            if (s == null) continue;
            PlateType t = new PlateType(id.toLowerCase(Locale.ROOT));
            t.load(s);
            plates.put(t.id, t);
        }
        plugin.getLogger().info("Завантажено платівок: " + plates.size());
    }

    public void save() {
        cfg.set("plates", null);
        for (PlateType t : plates.values()) {
            t.save(cfg.createSection("plates." + t.id));
        }
        plugin.files().saveAsync(plugin.files().file("items.yml"), cfg);
    }

    public Collection<PlateType> all() {
        return plates.values();
    }

    public PlateType get(String id) {
        return id == null ? null : plates.get(id.toLowerCase(Locale.ROOT));
    }

    /** Створює предмет-платівку. tagged=false — лише для відображення в GUI (без ID). */
    @SuppressWarnings("deprecation")
    public ItemStack create(PlateType t, int amount, boolean tagged) {
        ItemStack it = new ItemStack(t.material, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Text.item(t.name));
        List<Component> lore = new ArrayList<>();
        for (String line : t.lore) {
            lore.add(Text.item(line.replace("{level}", String.valueOf(t.level))));
        }
        if (!lore.isEmpty()) meta.lore(lore);
        if (t.customModelData > 0) {
            try {
                ItemMeta.class.getMethod("setCustomModelData", Integer.class).invoke(meta, t.customModelData);
            } catch (ReflectiveOperationException | RuntimeException ignored) {
            }
        }
        if (t.glow) meta.setEnchantmentGlintOverride(true);
        for (String f : t.itemFlags) {
            try {
                meta.addItemFlags(ItemFlag.valueOf(f.trim().toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (tagged) {
            meta.getPersistentDataContainer().set(keyId, PersistentDataType.STRING, t.id);
            meta.getPersistentDataContainer().set(keyLevel, PersistentDataType.INTEGER, t.level);
        }
        it.setItemMeta(meta);
        return it;
    }

    public boolean hasPlateTag(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(keyId, PersistentDataType.STRING);
    }

    /** Розпізнає платівку ТІЛЬКИ за PersistentDataContainer, а не за назвою. */
    public PlateType identify(ItemStack it) {
        if (!hasPlateTag(it)) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(keyId, PersistentDataType.STRING);
        return get(id);
    }

    public void give(Player p, PlateType t, int amount) {
        int remaining = Math.max(1, amount);
        while (remaining > 0) {
            ItemStack probe = new ItemStack(t.material);
            int n = Math.min(remaining, Math.max(1, probe.getMaxStackSize()));
            Map<Integer, ItemStack> left = p.getInventory().addItem(create(t, n, true));
            Location loc = p.getLocation();
            for (ItemStack rest : new HashMap<>(left).values()) {
                p.getWorld().dropItem(loc, rest);
            }
            remaining -= n;
        }
    }
}
