package ua.fliptime.platecases.manager;

import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.util.Text;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

public final class Messages {
    private final PlateCasesPlugin plugin;
    private YamlConfiguration cfg = new YamlConfiguration();

    public Messages(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        cfg = plugin.files().load("messages.yml");
        InputStream in = plugin.getResource("messages.yml");
        if (in != null) {
            cfg.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
        }
    }

    /** Пари kv: "ключ", "значення", ... замінюють {ключ} у тексті. */
    public String raw(String key, String... kv) {
        String s = cfg.getString(key);
        if (s == null) s = "&c[немає повідомлення: " + key + "]";
        s = s.replace("{prefix}", cfg.getString("prefix", ""));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return s;
    }

    public Component component(String key, String... kv) {
        return Text.parse(raw(key, kv));
    }

    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(component(key, kv));
    }

    public List<String> list(String key) {
        return cfg.getStringList(key);
    }
}
