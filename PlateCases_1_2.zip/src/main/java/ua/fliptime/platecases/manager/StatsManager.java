package ua.fliptime.platecases.manager;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.PlateType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class StatsManager {
    private final PlateCasesPlugin plugin;
    private final Map<String, Integer> perPlate = new HashMap<>();
    private final Map<UUID, Integer> perPlayer = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private int total;

    public StatsManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        perPlate.clear();
        perPlayer.clear();
        names.clear();
        total = 0;
        YamlConfiguration y = plugin.files().load("stats.yml");
        total = y.getInt("total", 0);
        ConfigurationSection pl = y.getConfigurationSection("plates");
        if (pl != null) {
            for (String k : pl.getKeys(false)) perPlate.put(k, pl.getInt(k));
        }
        ConfigurationSection pp = y.getConfigurationSection("players");
        if (pp != null) {
            for (String k : pp.getKeys(false)) {
                try {
                    UUID u = UUID.fromString(k);
                    perPlayer.put(u, pp.getInt(k + ".count"));
                    names.put(u, pp.getString(k + ".name", k));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    public void record(PlateType t, Player p) {
        total++;
        perPlate.merge(t.id, 1, Integer::sum);
        perPlayer.merge(p.getUniqueId(), 1, Integer::sum);
        names.put(p.getUniqueId(), p.getName());
        save();
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("total", total);
        for (Map.Entry<String, Integer> e : perPlate.entrySet()) {
            y.set("plates." + e.getKey(), e.getValue());
        }
        for (Map.Entry<UUID, Integer> e : perPlayer.entrySet()) {
            y.set("players." + e.getKey() + ".count", e.getValue());
            y.set("players." + e.getKey() + ".name", names.getOrDefault(e.getKey(), "?"));
        }
        plugin.files().saveAsync(plugin.files().file("stats.yml"), y);
    }

    public int uses(String plateId) {
        return perPlate.getOrDefault(plateId, 0);
    }

    public int total() {
        return total;
    }

    /** Топ гравців: рядки виду "Нік: кількість". */
    public List<String> top(int n) {
        List<Map.Entry<UUID, Integer>> list = new ArrayList<>(perPlayer.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        List<String> out = new ArrayList<>();
        for (int i = 0; i < Math.min(n, list.size()); i++) {
            Map.Entry<UUID, Integer> e = list.get(i);
            out.add(names.getOrDefault(e.getKey(), "?") + ": " + e.getValue());
        }
        return out;
    }
}
