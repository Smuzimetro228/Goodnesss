package ua.fliptime.platecases.manager;

import org.bukkit.configuration.file.YamlConfiguration;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.LootDefaults;
import ua.fliptime.platecases.model.LootTable;
import ua.fliptime.platecases.model.PlateType;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class LootManager {
    private final PlateCasesPlugin plugin;
    private final Map<String, LootTable> tables = new HashMap<>();

    public LootManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        tables.clear();
        for (PlateType t : plugin.plates().all()) {
            File f = plugin.files().file(t.lootFile);
            LootTable table = new LootTable();
            if (f.exists()) {
                table.load(YamlConfiguration.loadConfiguration(f));
            } else {
                table = LootDefaults.forLevel(t.level);
                YamlConfiguration y = new YamlConfiguration();
                table.save(y);
                plugin.files().saveAsync(f, y);
            }
            tables.put(t.id, table);
        }
    }

    public LootTable get(String plateId) {
        return tables.computeIfAbsent(plateId, k -> new LootTable());
    }

    public void save(String plateId) {
        PlateType t = plugin.plates().get(plateId);
        if (t == null) return;
        YamlConfiguration y = new YamlConfiguration();
        get(plateId).save(y);
        plugin.files().saveAsync(plugin.files().file(t.lootFile), y);
    }
}
