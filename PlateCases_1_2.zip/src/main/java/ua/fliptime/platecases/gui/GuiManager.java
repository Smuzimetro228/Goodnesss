package ua.fliptime.platecases.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.model.CaseBlock;
import ua.fliptime.platecases.model.LootEntry;
import ua.fliptime.platecases.model.LootTable;
import ua.fliptime.platecases.model.PlateType;
import ua.fliptime.platecases.util.Effects;
import ua.fliptime.platecases.util.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

/** Усі меню адміністратора: головне, редактор платівки, редактор луту, налаштування, статистика. */
public final class GuiManager {
    private record PendingInput(Consumer<String> handler, Runnable cancel) {
    }

    private final PlateCasesPlugin plugin;
    private final Map<UUID, PendingInput> pending = new ConcurrentHashMap<>();

    public GuiManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    // ================================================================ допоміжне

    private void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Text.item(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(Text.item(s));
            meta.lore(l);
        }
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack filler() {
        return item(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    private void addLore(ItemStack it, String... lines) {
        ItemMeta meta = it.getItemMeta();
        List<Component> l = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String s : lines) l.add(Text.item(s));
        meta.lore(l);
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
    }

    private static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format(Locale.US, "%.1f", d);
    }

    private static String onOff(boolean b) {
        return b ? "&aУвімкнено" : "&cВимкнено";
    }

    private ItemStack oneOf(ItemStack src) {
        ItemStack c = src.clone();
        c.setAmount(1);
        return c;
    }

    // ================================================================ введення з чату

    public void ask(Player p, String prompt, Consumer<String> handler, Runnable onCancel) {
        p.closeInventory();
        pending.put(p.getUniqueId(), new PendingInput(handler, onCancel));
        p.sendMessage(Text.parse(prompt));
        p.sendMessage(plugin.messages().component("input-hint"));
    }

    public boolean hasPending(Player p) {
        return pending.containsKey(p.getUniqueId());
    }

    public void clearPending(Player p) {
        pending.remove(p.getUniqueId());
    }

    public void handleChat(Player p, String msg) {
        PendingInput in = pending.remove(p.getUniqueId());
        if (in == null) return;
        String t = msg.trim();
        if (t.equalsIgnoreCase("скасувати") || t.equalsIgnoreCase("cancel")) {
            plugin.messages().send(p, "input-cancelled");
            in.cancel().run();
            return;
        }
        in.handler().accept(t);
    }

    // ================================================================ головне меню

    public void openMain(Player p) {
        Gui g = new Gui(Text.parse("&8PlateCases &7· Меню"), 45);
        g.fill(filler());
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        for (PlateType t : plugin.plates().all()) {
            if (i >= slots.length) break;
            ItemStack it = plugin.plates().create(t, 1, false);
            addLore(it, "", "&7ID: &f" + t.id, "&7Рівень: &f" + t.level,
                    "&7Предметів у луті: &f" + plugin.loot().get(t.id).entries().size(),
                    "&7Використано: &f" + plugin.stats().uses(t.id), "", "&eКлік — редагувати");
            g.set(slots[i++], it, e -> later(() -> openPlate(p, t)));
        }
        g.set(38, item(Material.CHEST, "&6Створення сундуків",
                "&7Поставити спеціальний сундук/бочку", "&7або видалити існуючі", "", "&eКлік"),
                e -> later(() -> openCases(p)));
        g.set(40, item(Material.COMPARATOR, "&bНалаштування", "&7Звуки, частинки, розміри", "", "&eКлік"),
                e -> later(() -> openSettings(p)));
        g.set(42, item(Material.BOOK, "&aСтатистика", "&7Скільки разів використано платівки", "", "&eКлік"),
                e -> later(() -> openStats(p)));
        p.openInventory(g.getInventory());
    }

    // ================================================================ створення сундуків

    public void openCases(Player p) {
        Gui g = new Gui(Text.parse("&8Створення сундуків"), 27);
        g.fill(filler());
        g.set(11, item(Material.CHEST, "&6Створити сундук", "&7Буде поставлено там, де ви стоїте", "",
                "&eКлік"), e -> {
            placeAndNotify(p, Material.CHEST);
            later(() -> openCases(p));
        });
        g.set(13, item(Material.BARREL, "&6Створити бочку", "&7Буде поставлено там, де ви стоїте", "",
                "&eКлік"), e -> {
            placeAndNotify(p, Material.BARREL);
            later(() -> openCases(p));
        });
        g.set(15, item(Material.PAPER, "&bВсього спеціальних блоків: &f" + plugin.cases().all().size(),
                "&7Список: &f/pcases list"));
        g.set(22, item(Material.ARROW, "&7Назад"), e -> later(() -> openMain(p)));
        p.openInventory(g.getInventory());
    }

    public void placeAndNotify(Player p, Material type) {
        CaseBlock cb = plugin.cases().place(p, type);
        if (cb == null) plugin.messages().send(p, "place-failed");
        else plugin.messages().send(p, "placed", "id", cb.id());
    }

    // ================================================================ редактор платівки

    public void openPlate(Player p, PlateType t) {
        Gui g = new Gui(Text.parse("&8Платівка &7· &f" + t.id), 45);
        g.fill(filler());
        LootTable table = plugin.loot().get(t.id);
        Runnable back = () -> openPlate(p, t);
        g.set(4, plugin.plates().create(t, 1, false));

        g.set(10, item(Material.CHEST, "&6Редактор луту", "&7Предметів: &f" + table.entries().size(),
                "&7Ролів: &f" + table.rolls(), "", "&eКлік"), e -> later(() -> openLoot(p, t, 0)));

        g.set(11, item(Material.NAME_TAG, "&6Змінити назву", "&7Зараз: &r" + t.name, "",
                "&eКлік — ввести в чаті"), e -> ask(p,
                "&eВведіть нову назву (&-коди, &#RRGGBB, MiniMessage):", s -> {
                    t.name = s;
                    plugin.plates().save();
                    plugin.messages().send(p, "input-saved");
                    openPlate(p, t);
                }, back));

        g.set(12, item(Material.ITEM_FRAME, "&6Змінити матеріал (текстуру)", "&7Зараз: &f" + t.material.name(), "",
                "&eКлік — взяти матеріал із предмета в основній руці",
                "&8Уже видані платівки зберігають старий вигляд"), e -> {
            ItemStack h = p.getInventory().getItemInMainHand();
            if (h.getType().isAir()) {
                plugin.messages().send(p, "hand-empty");
                return;
            }
            t.material = h.getType();
            plugin.plates().save();
            later(back);
        });

        g.set(13, item(Material.PAPER, "&6CustomModelData", "&7Зараз: &f" + t.customModelData, "",
                "&eЛКМ +1 / ПКМ -1", "&eShift: ±10"), e -> {
            int step = e.isShiftClick() ? 10 : 1;
            t.customModelData = Math.max(0, t.customModelData + (e.isLeftClick() ? step : -step));
            plugin.plates().save();
            later(back);
        });

        g.set(14, item(Material.ENCHANTED_BOOK, "&6Блиск", "&7Стан: " + onOff(t.glow), "", "&eКлік"), e -> {
            t.glow = !t.glow;
            plugin.plates().save();
            later(back);
        });

        g.set(15, item(Material.EXPERIENCE_BOTTLE, "&6Рівень платівки", "&7Зараз: &f" + t.level, "",
                "&eЛКМ +1 / ПКМ -1"), e -> {
            t.level = Math.max(1, t.level + (e.isLeftClick() ? 1 : -1));
            plugin.plates().save();
            later(back);
        });

        g.set(16, item(Material.OAK_SIGN, "&6Назва сундука (вікна луту)", "&7Зараз: &r" + t.chestTitle, "",
                "&eКлік — ввести в чаті"), e -> ask(p, "&eВведіть назву вікна сундука:", s -> {
            t.chestTitle = s;
            plugin.plates().save();
            plugin.messages().send(p, "input-saved");
            openPlate(p, t);
        }, back));

        g.set(19, item(Material.HOPPER, "&6Кількість ролів", "&7Зараз: &f" + table.rolls(),
                "&8Скільки разів перевіряється весь список луту", "", "&eЛКМ +1 / ПКМ -1"), e -> {
            table.setRolls(table.rolls() + (e.isLeftClick() ? 1 : -1));
            plugin.loot().save(t.id);
            later(back);
        });

        g.set(20, item(Material.NOTE_BLOCK, "&6Звук відкриття", "&7Зараз: &f" + t.openSound.key, "",
                "&eЛКМ — змінити в чаті", "&eПКМ — прослухати"), e -> {
            if (e.isRightClick()) {
                Effects.sound(p.getLocation(), t.openSound);
                return;
            }
            ask(p, "&eВведіть ключ звуку (напр. &fblock.chest.open&e):", s -> {
                t.openSound.key = s.toLowerCase(Locale.ROOT);
                plugin.plates().save();
                plugin.messages().send(p, "input-saved");
                openPlate(p, t);
            }, back);
        });

        g.set(21, item(Material.JUKEBOX, "&6Звук нагороди", "&7Зараз: &f" + t.revealSound.key, "",
                "&eЛКМ — змінити в чаті", "&eПКМ — прослухати"), e -> {
            if (e.isRightClick()) {
                Effects.sound(p.getLocation(), t.revealSound);
                return;
            }
            ask(p, "&eВведіть ключ звуку (напр. &fentity.player.levelup&e):", s -> {
                t.revealSound.key = s.toLowerCase(Locale.ROOT);
                plugin.plates().save();
                plugin.messages().send(p, "input-saved");
                openPlate(p, t);
            }, back);
        });

        g.set(23, item(Material.FIREWORK_STAR, "&6Частинки", "&7Стан: " + onOff(t.particlesEnabled), "",
                "&eКлік"), e -> {
            t.particlesEnabled = !t.particlesEnabled;
            plugin.plates().save();
            later(back);
        });

        g.set(24, item(Material.BLAZE_POWDER, "&6Тип частинок", "&7Зараз: &f" + t.particleType, "",
                "&eКлік — ввести в чаті (напр. END_ROD)"), e -> ask(p, "&eВведіть назву частинки:", s -> {
            if (Effects.particle(s) == null) {
                plugin.messages().send(p, "input-invalid");
            } else {
                t.particleType = s.toUpperCase(Locale.ROOT);
                plugin.plates().save();
                plugin.messages().send(p, "input-saved");
            }
            openPlate(p, t);
        }, back));

        g.set(25, item(Material.GLOWSTONE_DUST, "&6Кількість частинок", "&7Зараз: &f" + t.particleCount, "",
                "&eЛКМ +5 / ПКМ -5"), e -> {
            t.particleCount = Math.max(1, Math.min(500, t.particleCount + (e.isLeftClick() ? 5 : -5)));
            plugin.plates().save();
            later(back);
        });

        g.set(28, item(Material.DIAMOND, "&aОтримати платівку", "&7Використано: &f" + plugin.stats().uses(t.id), "",
                "&eЛКМ — 1 шт.  ПКМ — 10 шт."), e -> {
            plugin.plates().give(p, t, e.isLeftClick() ? 1 : 10);
            plugin.messages().send(p, "plate-received", "amount", e.isLeftClick() ? "1" : "10", "plate", t.name);
        });

        g.set(36, item(Material.ARROW, "&7Назад"), e -> later(() -> openMain(p)));
        p.openInventory(g.getInventory());
    }

    // ================================================================ редактор луту

    public void openLoot(Player p, PlateType t, int page) {
        LootTable table = plugin.loot().get(t.id);
        List<LootEntry> list = table.entries();
        int perPage = 45;
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        int pg = Math.max(0, Math.min(page, pages - 1));

        Gui g = new Gui(Text.parse("&8Лут &7· &f" + t.id + " &7(" + (pg + 1) + "/" + pages + ")"), 54);
        for (int i = 45; i < 54; i++) g.set(i, filler());

        for (int i = 0; i < perPage; i++) {
            int idx = pg * perPage + i;
            if (idx >= list.size()) break;
            LootEntry le = list.get(idx);
            ItemStack it = le.item.clone();
            it.setAmount(Math.max(1, Math.min(le.min, it.getMaxStackSize())));
            addLore(it, "", "&7Шанс: &e" + fmt(le.chance) + "%", "&7Кількість: &f" + le.min + "–" + le.max, "",
                    "&eЛКМ — редагувати", "&cShift+ПКМ — видалити");
            g.set(i, it, e -> {
                if (e.getClick() == ClickType.SHIFT_RIGHT) {
                    list.remove(le);
                    plugin.loot().save(t.id);
                    later(() -> openLoot(p, t, pg));
                } else {
                    later(() -> openEntry(p, t, le, pg));
                }
            });
        }

        if (pg > 0) g.set(45, item(Material.ARROW, "&7◀ Попередня"), e -> later(() -> openLoot(p, t, pg - 1)));
        g.set(46, item(Material.BARRIER, "&cНазад"), e -> later(() -> openPlate(p, t)));
        g.set(47, item(Material.EMERALD, "&aДодати предмет з руки", "&7Шанс 100%, кількість = стак у руці", "",
                "&eКлік"), e -> {
            ItemStack h = p.getInventory().getItemInMainHand();
            if (h.getType().isAir()) {
                plugin.messages().send(p, "hand-empty");
                return;
            }
            list.add(new LootEntry(oneOf(h), 100.0, h.getAmount(), h.getAmount()));
            plugin.loot().save(t.id);
            int last = Math.max(0, (list.size() - 1) / perPage);
            later(() -> openLoot(p, t, last));
        });
        g.set(49, item(Material.HOPPER, "&6Ролів: &f" + table.rolls(),
                "&8Скільки разів перевіряється весь список", "", "&eЛКМ +1 / ПКМ -1"), e -> {
            table.setRolls(table.rolls() + (e.isLeftClick() ? 1 : -1));
            plugin.loot().save(t.id);
            later(() -> openLoot(p, t, pg));
        });
        g.set(51, item(Material.WRITABLE_BOOK, "&aЗберегти", "&7Зміни зберігаються автоматично,", "&7кнопка лише для впевненості", "",
                "&eКлік"), e -> {
            plugin.loot().save(t.id);
            plugin.messages().send(p, "input-saved");
        });
        if (pg < pages - 1) g.set(53, item(Material.ARROW, "&7Наступна ▶"), e -> later(() -> openLoot(p, t, pg + 1)));
        p.openInventory(g.getInventory());
    }

    // ================================================================ редактор запису

    private void row(Gui g, int base, String title, Material mat, String value, int big, int small,
                     DoubleConsumer delta, Runnable refresh) {
        g.set(base + 1, item(Material.RED_STAINED_GLASS_PANE, "&c-" + big), e -> {
            delta.accept(-big);
            later(refresh);
        });
        g.set(base + 2, item(Material.RED_STAINED_GLASS_PANE, "&c-" + small), e -> {
            delta.accept(-small);
            later(refresh);
        });
        g.set(base + 4, item(mat, "&6" + title + ": &f" + value));
        g.set(base + 6, item(Material.LIME_STAINED_GLASS_PANE, "&a+" + small), e -> {
            delta.accept(small);
            later(refresh);
        });
        g.set(base + 7, item(Material.LIME_STAINED_GLASS_PANE, "&a+" + big), e -> {
            delta.accept(big);
            later(refresh);
        });
    }

    public void openEntry(Player p, PlateType t, LootEntry le, int backPage) {
        Gui g = new Gui(Text.parse("&8Редагування предмета"), 45);
        g.fill(filler());
        Runnable refresh = () -> openEntry(p, t, le, backPage);
        ItemStack shown = le.item.clone();
        shown.setAmount(Math.max(1, Math.min(le.min, shown.getMaxStackSize())));
        g.set(4, shown);

        row(g, 9, "Шанс", Material.GOLD_NUGGET, fmt(le.chance) + "%", 10, 1, d -> {
            le.addChance(d);
            plugin.loot().save(t.id);
        }, refresh);
        row(g, 18, "Мінімум", Material.IRON_NUGGET, String.valueOf(le.min), 10, 1, d -> {
            le.setMin(le.min + (int) d);
            plugin.loot().save(t.id);
        }, refresh);
        row(g, 27, "Максимум", Material.GOLD_INGOT, String.valueOf(le.max), 10, 1, d -> {
            le.setMax(le.max + (int) d);
            plugin.loot().save(t.id);
        }, refresh);

        g.set(36, item(Material.ARROW, "&7Назад"), e -> later(() -> openLoot(p, t, backPage)));
        g.set(44, item(Material.BARRIER, "&cВидалити предмет з луту"), e -> {
            plugin.loot().get(t.id).entries().remove(le);
            plugin.loot().save(t.id);
            later(() -> openLoot(p, t, backPage));
        });
        p.openInventory(g.getInventory());
    }

    // ================================================================ налаштування

    private void toggle(Gui g, Player p, int slot, Material m, String name, String path) {
        boolean v = plugin.getConfig().getBoolean(path);
        g.set(slot, item(m, name, "&7Стан: " + onOff(v), "", "&eКлік"), e -> {
            plugin.getConfig().set(path, !v);
            plugin.saveConfigAsync();
            later(() -> openSettings(p));
        });
    }

    private void sizeButton(Gui g, Player p, int slot, String name, String path) {
        int v = plugin.getConfig().getInt(path, 27);
        g.set(slot, item(Material.CHEST, name, "&7Розмір: &f" + v + " слотів", "", "&eЛКМ +9 / ПКМ -9"), e -> {
            int nv = Math.max(9, Math.min(54, v + (e.isLeftClick() ? 9 : -9)));
            plugin.getConfig().set(path, nv);
            plugin.saveConfigAsync();
            later(() -> openSettings(p));
        });
    }

    public void openSettings(Player p) {
        Gui g = new Gui(Text.parse("&8Налаштування"), 36);
        g.fill(filler());
        toggle(g, p, 10, Material.NOTE_BLOCK, "&6Звуки", "effects.sounds-enabled");
        toggle(g, p, 11, Material.FIREWORK_STAR, "&6Частинки", "effects.particles-enabled");
        toggle(g, p, 12, Material.BLAZE_ROD, "&6Анімація відкриття", "effects.animation-enabled");
        toggle(g, p, 13, Material.WRITABLE_BOOK, "&6Логування відкриттів", "settings.log-openings");
        toggle(g, p, 14, Material.CLOCK, "&6Витрата платівки в креативі", "settings.consume-in-creative");
        toggle(g, p, 15, Material.DROPPER, "&6Повертати залишок луту при закритті", "close.drop-remaining");
        sizeButton(g, p, 19, "&6Розмір вікна сундука", "inventory-size.chest");
        sizeButton(g, p, 20, "&6Розмір вікна подвійного сундука", "inventory-size.double-chest");
        sizeButton(g, p, 21, "&6Розмір вікна бочки", "inventory-size.barrel");
        g.set(25, item(Material.REPEATER, "&bПерезавантажити конфіги", "", "&eКлік"), e -> {
            plugin.loadAll();
            plugin.messages().send(p, "reloaded");
            later(() -> openSettings(p));
        });
        g.set(27, item(Material.ARROW, "&7Назад"), e -> later(() -> openMain(p)));
        p.openInventory(g.getInventory());
    }

    // ================================================================ статистика

    public void openStats(Player p) {
        Gui g = new Gui(Text.parse("&8Статистика"), 36);
        g.fill(filler());
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        for (PlateType t : plugin.plates().all()) {
            if (i >= slots.length) break;
            ItemStack it = plugin.plates().create(t, 1, false);
            addLore(it, "", "&7Відкрито сундуків: &a" + plugin.stats().uses(t.id));
            g.set(slots[i++], it);
        }
        List<String> top = plugin.stats().top(5);
        List<String> lore = new ArrayList<>();
        lore.add("&7Всього відкриттів: &a" + plugin.stats().total());
        lore.add("");
        lore.add("&6Топ гравців:");
        if (top.isEmpty()) lore.add("&8—");
        for (String s : top) lore.add("&7" + s);
        g.set(4, item(Material.NETHER_STAR, "&aЗагальна статистика", lore.toArray(new String[0])));
        g.set(27, item(Material.ARROW, "&7Назад"), e -> later(() -> openMain(p)));
        p.openInventory(g.getInventory());
    }
}
