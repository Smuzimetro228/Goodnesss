package ua.fliptime.platecases.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/** Захищений адмін-GUI: усі кліки скасовуються, дії виконуються лише через зареєстровані кнопки. */
public final class Gui implements InventoryHolder {
    private final Inventory inventory;
    private final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();

    public Gui(Component title, int size) {
        this.inventory = Bukkit.createInventory(this, size, title);
    }

    public Gui set(int slot, ItemStack item, Consumer<InventoryClickEvent> action) {
        inventory.setItem(slot, item);
        if (action != null) actions.put(slot, action);
        return this;
    }

    public Gui set(int slot, ItemStack item) {
        return set(slot, item, null);
    }

    public void fill(ItemStack filler) {
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, filler);
    }

    public void click(InventoryClickEvent e) {
        Consumer<InventoryClickEvent> a = actions.get(e.getRawSlot());
        if (a != null) a.accept(e);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
