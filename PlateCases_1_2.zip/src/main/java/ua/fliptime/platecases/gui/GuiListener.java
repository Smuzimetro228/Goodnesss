package ua.fliptime.platecases.gui;

import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ua.fliptime.platecases.PlateCasesPlugin;
import ua.fliptime.platecases.util.Text;

public final class GuiListener implements Listener {
    private final PlateCasesPlugin plugin;

    public GuiListener(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Gui gui)) return;
        e.setCancelled(true); // жодних сторонніх змін
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!p.hasPermission("platecases.admin")) {
            p.closeInventory();
            return;
        }
        if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getView().getTopInventory().getSize()) return;
        gui.click(e);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        if (!plugin.gui().hasPending(p)) return;
        e.setCancelled(true);
        String text = Text.plain(e.message());
        Bukkit.getScheduler().runTask(plugin, () -> plugin.gui().handleChat(p, text));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.gui().clearPending(e.getPlayer());
    }
}
