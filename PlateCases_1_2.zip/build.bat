@echo off
chcp 65001 >nul
mvn -B clean package
echo.
echo Готово! JAR лежить у папці target
pause
