#!/bin/sh
mvn -B clean package && echo "Готово! JAR у папці target"
